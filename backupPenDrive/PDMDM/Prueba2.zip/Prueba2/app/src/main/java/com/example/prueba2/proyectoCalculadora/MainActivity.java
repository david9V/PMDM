package com.example.prueba2.proyectoCalculadora;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.prueba2.R;

public class MainActivity extends AppCompatActivity {
    Button n0, n1, n2, n3, n4, n5, n6,  n7, n8, n9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_calculadora2);
    }
}

/*
String cadena = myTextView.getString().ToString()
myTextView.append("4")
 */