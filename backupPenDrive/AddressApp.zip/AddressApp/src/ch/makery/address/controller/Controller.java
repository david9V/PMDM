package ch.makery.address.controller;

import ch.makery.address.Main;
import ch.makery.address.model.ExcepcionPerson;
import ch.makery.address.model.Model;
import ch.makery.address.model.Person;
import ch.makery.address.model.PersonVO;
import ch.makery.address.model.repository.PersonaRepository;
import ch.makery.address.model.repository.impl.PersonaRepositoryImpl;
import ch.makery.address.util.DateUtil;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import ch.makery.address.util.PersonConverter;

import java.lang.reflect.Array;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Optional;

import static ch.makery.address.util.PersonConverter.*;

/**
 * The controller for the birthday statistics view.
 *
 * @author David Vilches
 */
public class Controller {
    @FXML
    private TableView<Person> personTable;
    @FXML
    private TableColumn<Person, String> firstNameColumn;
    @FXML
    private TableColumn<Person, String> lastNameColumn;


    @FXML
    private Label firstNameLabel;
    @FXML
    private Label lastNameLabel;
    @FXML
    private Label streetLabel;
    @FXML
    private Label postalCodeLabel;
    @FXML
    private Label cityLabel;
    @FXML
    private Label birthdayLabel;



    // Reference to the main application.
    private Main main;

    private Model modelo;

    private ArrayList<PersonVO> lista = new ArrayList<>();

    /**
     * The constructor.
     * The constructor is called before the initialize() method.
     */
    public Controller() {
    }

    /**
     *
     * @param m
     */
    public void setModelo(Model m){
        this.modelo = m;
    }

    /**
     *
     * @return
     */
    public Model getModelo(){
        return this.modelo;
    }


    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     * @return void
     */
    @FXML
    private void initialize() {
        // Initialize the person table with the two columns.
        firstNameColumn.setCellValueFactory(
                cellData -> cellData.getValue().firstNameProperty());
        lastNameColumn.setCellValueFactory(
                cellData -> cellData.getValue().lastNameProperty());

        // Clear person details.
        showPersonDetails(null);

        // Listen for selection changes and show the person details when changed.
        personTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> showPersonDetails(newValue));
    }


    /**
     * Is called by the main application to give a reference back to itself.
     *
     * @param main
     */
    public void setMainApp(Main main) {
        this.main = main;

        // Add observable list data to the table
        personTable.setItems(main.getPersonData());
    }

    /**
     * Fills all text fields to show details about the person.
     * If the specified person is null, all text fields are cleared.
     *
     * @param person the person or null
     */
    private void showPersonDetails(Person person) {
        if (person != null) {
            // Fill the labels with info from the person object.
            firstNameLabel.setText(person.getFirstName());
            lastNameLabel.setText(person.getLastName());
            streetLabel.setText(person.getStreet());
            postalCodeLabel.setText(Integer.toString(person.getPostalCode()));
            cityLabel.setText(person.getCity());

            birthdayLabel.setText(DateUtil.format(person.getBirthday()));

        } else {
            // Person is null, remove all the text.
            firstNameLabel.setText("");
            lastNameLabel.setText("");
            streetLabel.setText("");
            postalCodeLabel.setText("");
            cityLabel.setText("");
            birthdayLabel.setText("");
        }
    }

    /**
     * Called when the user clicks on the delete button.
     */
    /**
     * Called when the user clicks on the delete button.
     * @return void
     */
    @FXML
    private void handleDeletePerson() throws ExcepcionPerson {
        int selectedIndex = personTable.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            Person p = personTable.getItems().get(selectedIndex);
            modelo.borrarPersona(p.getId());
            personTable.getItems().remove(selectedIndex);
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("No ha seleccionado ninguna persona");
            alert.setContentText("Por favor, elija una persona de la agenda");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get().equals(ButtonType.OK)) {
                alert.close();
            }
        }
    }

    /**
     * Called when the user clicks the new button. Opens a dialog to edit
     * details for a new person.
     * @return  void
     */
    @FXML
    private void handleNewPerson() throws ExcepcionPerson {
        if (main.getPersonData().size() == 50){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("La base de datos está llena");
            alert.setContentText("El máximo de personas es de 50");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get().equals(ButtonType.OK)) {
                alert.close();
            }
        } else{
            Person tempPerson = new Person();
            boolean okClicked = main.showPersonEditDialog(tempPerson);
            if (okClicked) {
                tempPerson.setId(modelo.recuperarUltimoId() + 1);
                main.getPersonData().add(tempPerson);
                modelo.añadirPersona(convertirPtoPVO(tempPerson));
            }
        }

    }

    /**
     * Called when the user clicks the edit button. Opens a dialog to edit
     * details for the selected person.
     * @return void
     */
    @FXML
    private void handleEditPerson() throws ExcepcionPerson {
        Person selectedPerson = personTable.getSelectionModel().getSelectedItem();
        if (selectedPerson != null) {
            boolean okClicked = main.showPersonEditDialog(selectedPerson);
            if (okClicked) {
                modelo.modificarPersona(convertirPtoPVO(selectedPerson));
                showPersonDetails(selectedPerson);
            }

        } else {
            // Nothing selected.
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("No ha seleccionado ninguna persona");
            alert.setContentText("Por favor, elija una persona de la agenda");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get().equals(ButtonType.OK)) {
                alert.close();
            }
        }
    }



}