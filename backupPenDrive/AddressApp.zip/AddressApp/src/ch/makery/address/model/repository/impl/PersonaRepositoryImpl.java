package ch.makery.address.model.repository.impl;

import ch.makery.address.model.ExcepcionPerson;
import ch.makery.address.model.PersonVO;
import ch.makery.address.model.repository.PersonaRepository;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

public class PersonaRepositoryImpl implements PersonaRepository {
    private final ConexionJDBC conexion = new ConexionJDBC();
    private Statement stmt;
    private String sentencia;
    private ArrayList<PersonVO> lista;

    private PersonVO p;

    public PersonaRepositoryImpl(){
    }

    /**
     *
     * @param person
     * @throws ExcepcionPerson
     */
    @Override
    public void guardar(PersonVO person) throws ExcepcionPerson {
        try {
            Connection conn = this.conexion.conectarBD();
                this.stmt = conn.createStatement();
                this.sentencia = "INSERT INTO personas (first_name, last_name, street, postal_code, city, birthday) VALUES ('" + person.getFirstName() + "','" + person.getLastName() + "', '" + person.getStreet() + "', " + person.getPostalCode() + ", '" + person.getCity() + "', '" + person.getBirthday().toString() + "');";
                this.stmt.executeUpdate(this.sentencia);
                this.stmt.close();
            this.conexion.desconectarBD(conn);
        } catch (SQLException var3) {
            System.out.println(var3);
            throw new ExcepcionPerson("No se ha podido realizar la operación");
        }
    }

    /**
     *
     * @param idPersona
     * @throws ExcepcionPerson
     */
    @Override
    public void eliminar(int idPersona) throws ExcepcionPerson {
        try {
            Connection conn = this.conexion.conectarBD();
            this.stmt = conn.createStatement();
            Statement comando = conn.createStatement();
            String sql = String.format("DELETE FROM personas WHERE id = %d", idPersona);
            comando.executeUpdate(sql);
            this.conexion.desconectarBD(conn);
        } catch (SQLException var5) {
            throw new ExcepcionPerson("No se ha podido realizar la eliminación");
        }
    }

    /**
     *
     * @param p
     * @throws ExcepcionPerson
     */
    @Override
    public void actualizar(PersonVO p) throws ExcepcionPerson {
        try {
            Connection conn = this.conexion.conectarBD();
            this.stmt = conn.createStatement();
            String sql = String.format("UPDATE personas SET id= '%d', first_name = '%s', last_name = '%s', street = '%s', postal_code = '%d', city = '%s', birthday = '%s' WHERE id = %d", p.getId(), p.getFirstName(), p.getLastName(), p.getStreet(), p.getPostalCode(), p.getCity(), p.getBirthday(), p.getId());
            this.stmt.executeUpdate(sql);
        } catch (Exception var4) {
            throw new ExcepcionPerson("No se ha podido realizar la edición");
        }
    }

    /**
     *
     * @return
     * @throws ExcepcionPerson
     */
    @Override
    public ArrayList<PersonVO> cargar() throws ExcepcionPerson {
        try {
            Connection conn = this.conexion.conectarBD();
            this.lista = new ArrayList();
            this.stmt = conn.createStatement();
            this.sentencia = "SELECT * FROM personas";
            ResultSet rs = this.stmt.executeQuery(this.sentencia);

            while(rs.next()) {
                Integer id = rs.getInt("id");
                String fn = rs.getString("first_name");
                String ln = rs.getString("last_name");
                String st = rs.getString("street");
                Integer pc = rs.getInt("postal_code");
                String city = rs.getString("city");
                String birthday = rs.getString("birthday");

                this.p = new PersonVO(id, fn, ln, st, pc, city, transformarFecha(birthday));
                this.lista.add(this.p);
            }

            this.conexion.desconectarBD(conn);
            return this.lista;
        } catch (SQLException var6) {
            throw new ExcepcionPerson("No se ha podido realizar la operación");
        }
    }

    /**
     *
     * @param fecha
     * @return
     */
    public LocalDate transformarFecha(String fecha){
        String[] datos = fecha.split("-");
        return LocalDate.of(Integer.parseInt(datos[0]), Integer.parseInt(datos[1]), Integer.parseInt(datos[2]));
    }

    /**
     *
     * @return
     * @throws ExcepcionPerson
     */
    public int lastId() throws ExcepcionPerson {
        int idPersona = 0;

        try {
            Connection conn = this.conexion.conectarBD();
            Statement comando = conn.createStatement();

            for(ResultSet registro = comando.executeQuery("SELECT id FROM personas ORDER BY id DESC LIMIT 1"); registro.next(); idPersona = registro.getInt("id")) {

            }

            return idPersona;
        } catch (SQLException var5) {
            throw new ExcepcionPerson( "No se ha podido realizar la busqueda del ID");
        }
    }
}
