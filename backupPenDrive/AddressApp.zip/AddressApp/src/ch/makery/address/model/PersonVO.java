package ch.makery.address.model;

import java.time.LocalDate;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * Model class for a Person.
 *
 * @author David Vilches
 */
public class PersonVO {

    private int id;
    private String firstName;
    private String lastName;
    private String street;
    private int postalCode;
    private String city;
    private LocalDate birthday;

    /**
     * Default constructor.
     */
    public PersonVO() {
        this(null, null);
    }

    /**
     * Constructor with some initial data.
     *
     * @param firstName
     * @param lastName
     */
    public PersonVO(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;

        // Some initial dummy data, just for convenient testing.
        this.street = new String("some street");
        this.postalCode = 1234;
        this.city = new String("some city");
        this.birthday = (LocalDate.of(1999, 2, 21));
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "PersonVO{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", street='" + street + '\'' +
                ", postalCode=" + postalCode +
                ", city='" + city + '\'' +
                ", birthday=" + birthday +
                '}';
    }

    public PersonVO(int id, String firstName, String lastName, String street, int postalCode, String city, LocalDate birthday){
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.street = street;
        this.postalCode = postalCode;
        this.city = city;
        this.birthday = birthday;
    }

    public PersonVO(String firstName, String lastName, String street, int postalCode, String city, LocalDate birthday){
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.street = street;
        this.postalCode = postalCode;
        this.city = city;
        this.birthday = birthday;
    }

    /**
     *
     * @return
     */
    public String getSqlBirthday(){
        String birthday = "";
        birthday += this.birthday.getYear() + this.birthday.getMonthValue() + this.birthday.getDayOfMonth();
        return birthday;
    }

    /**
     *
     * @return
     */
    public int getId(){
        return this.id;
    }

    /**
     *
     * @param id
     */
    public void setId(int id){
        this.id = id;
    }

    /**
     *
     * @return String firstName devuelve el nombre de la persona
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     *
     * @param firstName establece el nombre de una persona
     * @return void
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     *
     * @return lastName devuelve el apellido de la persona
     */
    public String getLastName() {
        return lastName;
    }

    /**
     *
     * @param lastName  establece el apellido de una persona
     * @return void
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     *
     * @return street devuelve la calle
     */
    public String getStreet() {
        return street;
    }

    /**
     *
     * @param street
     * @return void
     */
    public void setStreet(String street) {
        this.street = street;
    }

    /*
       public String streetProperty() {
           return street;
       }
   */

    /**
     *
     * @return
     */
    public int getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(int postalCode) {
        this.postalCode = postalCode;
    }
    /*
        public IntegerProperty postalCodeProperty() {
            return postalCode;
        }
    */

    /**
     *
     * @return
     */
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
    /*
        public StringProperty cityProperty() {
            return city;
        }
    */

    /**
     *
     * @return
     */
    public LocalDate getBirthday() {
        return birthday;
    }

    /**
     *
     * @param birthday
     */
    public void setBirthday(LocalDate birthday) {
        this.birthday = birthday;
    }
/*
    public ObjectProperty<LocalDate> birthdayProperty() {
        return birthday;
    }

 */
}