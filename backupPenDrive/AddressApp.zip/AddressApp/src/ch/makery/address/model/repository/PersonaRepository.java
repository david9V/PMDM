package ch.makery.address.model.repository;

import ch.makery.address.model.ExcepcionPerson;
import ch.makery.address.model.PersonVO;

import java.util.ArrayList;

public interface PersonaRepository {
    /**
     *
     * @param person
     * @throws ExcepcionPerson
     */
    void guardar(PersonVO person) throws ExcepcionPerson;

    /**
     *
     * @param idPersona
     * @throws ExcepcionPerson
     */
    void eliminar(int idPersona) throws ExcepcionPerson;

    /**
     *
     * @param p
     * @throws ExcepcionPerson
     */
    void actualizar(PersonVO p) throws ExcepcionPerson;

    /**
     *
     * @return
     * @throws ExcepcionPerson
     */
    ArrayList<PersonVO> cargar() throws ExcepcionPerson;

    /**
     *
     * @return
     * @throws ExcepcionPerson
     */
    int lastId() throws ExcepcionPerson;
}
