package ch.makery.address.model;

import ch.makery.address.model.repository.PersonaRepository;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

import java.util.ArrayList;

public class Model {
    private PersonaRepository repo;

    private IntegerProperty longitudTabla = new SimpleIntegerProperty();

    /**
     *
     * @throws ExcepcionPerson
     */
    public void setLongitudTabla() throws ExcepcionPerson {
        this.longitudTabla.setValue(recuperarTamaño());
    }

    public Model(){
    }

    /**
     *
     * @return
     */
    public IntegerProperty getLongitudTabla(){
        return this.longitudTabla;
    }

    /**
     *
     * @param p
     */
    public void setRep(PersonaRepository p){
        this.repo = p;
    }

    /**
     *
     * @return
     */
    public PersonaRepository getRep(){
        return this.repo;
    }

    /**
     *
     * @param person
     * @throws ExcepcionPerson
     */
    public void añadirPersona(PersonVO person) throws ExcepcionPerson {
        this.repo.guardar(person);
        this.longitudTabla.setValue(this.longitudTabla.getValue() + 1);
    }

    /**
     *
     * @param idPersona
     * @throws ExcepcionPerson
     */
    public void borrarPersona(int idPersona) throws ExcepcionPerson {
        repo.eliminar(idPersona);
        this.longitudTabla.setValue(this.longitudTabla.getValue() - 1);
    }

    /**
     *
     * @param p
     * @throws ExcepcionPerson
     */
    public void modificarPersona(PersonVO p) throws ExcepcionPerson {
        repo.actualizar(p);
    }

    /**
     *
     * @return
     * @throws ExcepcionPerson
     */
    public ArrayList<PersonVO> recuperarPersonas() throws ExcepcionPerson{
        return this.repo.cargar();
    }

    /**
     *
     * @return
     * @throws ExcepcionPerson
     */
    public int recuperarTamaño() throws ExcepcionPerson {
        return this.repo.cargar().size();
    }

    /**
     *
     * @return
     * @throws ExcepcionPerson
     */
    public int recuperarUltimoId() throws ExcepcionPerson {
        return this.repo.lastId();
    }

}
