package ch.makery.address.model;

import java.time.LocalDate;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * Model class for a Person.
 *
 * @author David Vilches
 */
public class Person {

    private final IntegerProperty id;
    private final StringProperty firstName;
    private final StringProperty lastName;
    private final StringProperty street;
    private final IntegerProperty postalCode;
    private final StringProperty city;
    private final ObjectProperty<LocalDate> birthday;

    /**
     * Default constructor.
     */
    public Person() {
        this(null, null);
    }

    /**
     * Constructor with some initial data.
     *
     * @param firstName
     * @param lastName
     */
    public Person(String firstName, String lastName) {
        this.id = new SimpleIntegerProperty(123);
        this.firstName = new SimpleStringProperty(firstName);
        this.lastName = new SimpleStringProperty(lastName);

        // Some initial dummy data, just for convenient testing.
        this.street = new SimpleStringProperty("some street");
        this.postalCode = new SimpleIntegerProperty(1234);
        this.city = new SimpleStringProperty("some city");
        this.birthday = new SimpleObjectProperty<LocalDate>(LocalDate.of(1999, 2, 21));
    }

    public Person(IntegerProperty id, StringProperty firstName, StringProperty lastName, StringProperty street, IntegerProperty postalCode, StringProperty city, ObjectProperty<LocalDate> birthday){
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.street = street;
        this.postalCode = postalCode;
        this.city = city;
        this.birthday = birthday;
    }

    /**
     *
     * @return String firstName devuelve el nombre de la persona
     */
    public String getFirstName() {
        return this.firstName.get();
    }

    /**
     *
     * @param firstName establece el nombre de una persona
     * @return void
     */
    public void setFirstName(String firstName) {
        this.firstName.set(firstName);
    }
    
    public void setId(int id){
        this.id.set(id);
    }
    
    public int getId(){
        return this.id.get();
    }

    /**
     *
     * @return String firstName devuelve el nombre de la persona
     */
    public StringProperty firstNameProperty() {
        return firstName;
    }

    /**
     *
     * @return lastName devuelve el apellido de la persona
     */
    public String getLastName() {
        return lastName.get();
    }

    /**
     *
     * @param lastName  establece el apellido de una persona
     * @return void
     */
    public void setLastName(String lastName) {
        this.lastName.set(lastName);
    }

    /**
     *
     * @return lastName devuelve el apellido
     */
    public StringProperty lastNameProperty() {
        return lastName;
    }

    /**
     *
     * @return street devuelve la calle
     */
    public String getStreet() {
        return street.get();
    }

    /**
     *
     * @param street
     * @return void
     */
    public void setStreet(String street) {
        this.street.set(street);
    }

 /*
    public StringProperty streetProperty() {
        return street;
    }
*/

    /**
     *
     * @return
     */
    public int getPostalCode() {
        return postalCode.get();
    }

    /**
     *
     * @param postalCode
     */
    public void setPostalCode(int postalCode) {
        this.postalCode.set(postalCode);
    }
/*
    public IntegerProperty postalCodeProperty() {
        return postalCode;
    }
*/

    /**
     *
     * @return
     */
    public String getCity() {
        return city.get();
    }

    /**
     *
     * @param city
     */
    public void setCity(String city) {
        this.city.set(city);
    }
/*
    public StringProperty cityProperty() {
        return city;
    }
*/

    /**
     *
     * @return
     */
    public LocalDate getBirthday() {
        return birthday.get();
    }

    /**
     *
     * @param birthday
     */
    public void setBirthday(LocalDate birthday) {
        this.birthday.set(birthday);
    }
/*
    public ObjectProperty<LocalDate> birthdayProperty() {
        return birthday;
    }

 */
}