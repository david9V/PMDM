package ch.makery.address.util;

import ch.makery.address.model.Person;
import ch.makery.address.model.PersonVO;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.time.LocalDate;
import java.util.ArrayList;

public class PersonConverter {
    /**
     *
     * @param lista
     * @return
     */
    public  static ObservableList<Person> convertirPersonVOtoPerson(ArrayList<PersonVO> lista){
        ObservableList<Person> p = FXCollections.observableArrayList();
        for (int i = 0; i < lista.size(); i++){
            IntegerProperty id = new SimpleIntegerProperty(lista.get(i).getId());
            StringProperty fn  = new SimpleStringProperty(lista.get(i).getFirstName());
            StringProperty ln  = new SimpleStringProperty(lista.get(i).getLastName());
            StringProperty st  = new SimpleStringProperty(lista.get(i).getStreet());
            IntegerProperty pc  = new SimpleIntegerProperty(lista.get(i).getPostalCode());
            StringProperty city  = new SimpleStringProperty(lista.get(i).getCity());
            ObjectProperty<LocalDate> bd  = new SimpleObjectProperty<LocalDate>(lista.get(i).getBirthday());
            Person persona = new Person(id, fn, ln, st, pc, city, bd);
            p.add(persona);
        }
        return p;
    }

    /**
     *
     * @param lista
     * @return
     */
    public static ArrayList<PersonVO> convertirPersontoPersonVO(ObservableList<Person> lista){
        ArrayList<PersonVO> p = new ArrayList<>();
        for (int i = 0; i < lista.size(); i++){
            String fn = lista.get(i).getFirstName();
            String ln = lista.get(i).getLastName();
            String st = lista.get(i).getStreet();
            int pc = lista.get(i).getPostalCode();
            String city = lista.get(i).getCity();
            LocalDate bd = lista.get(i).getBirthday();
            PersonVO person = new PersonVO(fn, ln, st, pc, city, bd);
            p.add(person);
        }
        return p;
    }

    /**
     *
     * @param p
     * @return
     */
    public static PersonVO convertirPtoPVO(Person p){
        int id = p.getId();
        String fn = p.getFirstName();
        String ln = p.getLastName();
        String st = p.getStreet();
        int pc = p.getPostalCode();
        String city = p.getCity();
        LocalDate bd = p.getBirthday();
        PersonVO person = new PersonVO(id, fn, ln, st, pc, city, bd);

        return person;
    }

}
