package ch.makery.address.model;

public interface Conversor {
    float convertirA_B(float n, float mult); // CONVERSIÓN EN UN SENTIDO
    float convertirB_A(float n, float mult); // CONVERSiÓN EN EL SENTIDO OPUESTO

}
