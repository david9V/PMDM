package ch.makery.address.controller;

public class Controller {
}
