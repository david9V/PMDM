package act;

public class Excepcion  extends Exception{
	
	public Excepcion (String msg) {
		super(msg);
	}
	
	public Excepcion() {
		
	}
	
	public void setMsg(String msg) {
		this.setMsg(msg);
	}
}
