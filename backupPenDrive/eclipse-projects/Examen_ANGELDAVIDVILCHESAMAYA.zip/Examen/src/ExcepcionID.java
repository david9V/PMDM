
public class ExcepcionID extends Exception{
	
	public ExcepcionID (String msg) {
		super(msg);
	}
	
	public ExcepcionID() {
		
	}
	
	public void setMsg(String msg) {
		this.setMsg(msg);
	}
	
}
