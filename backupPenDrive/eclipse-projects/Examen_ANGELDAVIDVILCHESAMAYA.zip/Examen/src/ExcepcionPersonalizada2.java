
public class ExcepcionPersonalizada2 extends Exception{
	
	public ExcepcionPersonalizada2 (String msg) {
		super(msg);
	}
	
	public ExcepcionPersonalizada2() {
		
	}
	
	public void setMsg(String msg) {
		this.setMsg(msg);
	}
	
}
