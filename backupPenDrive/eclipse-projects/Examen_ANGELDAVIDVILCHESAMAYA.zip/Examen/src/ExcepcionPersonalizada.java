
public class ExcepcionPersonalizada extends Exception{
	
	public ExcepcionPersonalizada (String msg) {
		super(msg);
	}
	
	public ExcepcionPersonalizada() {
		
	}
	
	public void setMsg(String msg) {
		this.setMsg(msg);
	}
	
}
