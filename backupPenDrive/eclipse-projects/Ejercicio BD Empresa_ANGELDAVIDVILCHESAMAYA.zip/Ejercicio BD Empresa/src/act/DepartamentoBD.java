package act;

import java.sql.Statement;

public class DepartamentoBD {
	GestionBD conexion;
	String instruccion;

	Statement sentencia;
	
}
