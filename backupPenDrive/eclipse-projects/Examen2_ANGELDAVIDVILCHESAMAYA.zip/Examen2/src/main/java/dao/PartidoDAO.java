package dao;

public class PartidoDAO {

}
