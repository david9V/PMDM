package com.example.pmdm;


import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class DatosActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_act_intent2);
        Bundle extras = getIntent().getExtras();
        String anio = extras.getString("Año");
        String mes = extras.getString("Mes");
        Toast.makeText(this, "Año: " + anio + " Mes: " + mes, Toast.LENGTH_SHORT).show();

    }

}
