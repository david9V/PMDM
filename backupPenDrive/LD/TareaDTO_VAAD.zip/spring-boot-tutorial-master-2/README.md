# spring-boot-tutorial
 Development of a small project with MVC architecture, oriented to REST microservices; applying the technologies: Spring Boot, JPA, Hibernate and PostgreSQL.
 
 Video-tutorial = https://www.youtube.com/watch?v=3D1gpPknmhA&list=PLTlW-4AC8QLhHATvEWkif-UdCgJZtRR4f&index=2&t=0s&fbclid=IwAR1wsVTNZLO4rjyGf6Gh6YUfGGg_9Ze9d6nIrnFF1N54A4w05CQ4nnQOxTA
